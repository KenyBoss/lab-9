import java.util.ArrayList;

public class Player {
    private String name;
    private Room currentRoom;
    private Item inventory; // Store a single item

    public Player(String name, Room startingRoom) {
        this.name = name;
        this.currentRoom = startingRoom;
        this.inventory = null; // Start with no item
    }

    public String getName() {
        return name;
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(Room room) {
        this.currentRoom = room;
    }

    public Item getInventory() {
        return inventory;
    }

    public void takeItem(Item item) {
        this.inventory = item; // Take the item
    }

    public void dropItem() {
        this.inventory = null; // Drop the item
    }
}