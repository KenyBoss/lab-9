
/**
 * Enumeration Direction - écrire ici la description de l'énumération
 *
 * @author (votre nom)
 * @version (numéro de version ou date)
 */
public enum Direction
{
    
    NORTH, SOUTH, EAST, WEST
}

